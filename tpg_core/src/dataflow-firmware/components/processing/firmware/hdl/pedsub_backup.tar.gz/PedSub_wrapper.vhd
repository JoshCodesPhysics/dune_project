----------------------------------------------------------------------------------
-- Company: Rutherford Appleton Laboratory 
-- Engineer: Konstantinos Manolopoulos
-- 
-- Create Date: 06/08/2020 07:23:38 PM
-- Design Name: 
-- Module Name: PedSub_wrapper - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

use work.dtpc_stream_defs.all;


entity PedSub_wrapper is
generic (    
    ENABLE_SSR  : boolean := TRUE    
);
Port ( 
    clk                : in  std_logic; 
    reset              : in  std_logic; 
    localreset         : in  std_logic;  
    s_axis_data_w      : in  dtpc_axis4_w;
    s_axis_data_r      : out dtpc_axis4_r;    
    m_axis_data_w      : out dtpc_axis4_w;
    m_axis_data_r      : in  dtpc_axis4_r;
    --PedSub validation signals
    pedSub_valid       : out  std_logic;
    pedSub_median      : out  std_logic_vector(11 downto 0);
    pedSub_accum       : out  std_logic_vector(11 downto 0)
);
end PedSub_wrapper;


architecture Behavioral of PedSub_wrapper is

signal pedsub_rst : std_logic := '0';
signal start : STD_LOGIC := '0';
signal done  : STD_LOGIC := '0';
signal idle  : STD_LOGIC := '0';


begin

  pedsub_rst <= reset or localreset;

  gen_pedsub: if ENABLE_SSR generate
    pedsub_ssr: entity work.PedSub_SSR
    port map( 
      clk            => clk, 
      reset          => reset,   
      s_axis_data_w  => s_axis_data_w,
      s_axis_data_r  => s_axis_data_r,    
      m_axis_data_w  => m_axis_data_w,
      m_axis_data_r  => m_axis_data_r,
      pedSub_valid   => pedSub_valid,
      pedSub_median  => pedSub_median,
      pedSub_accum   => pedSub_accum
    );
  else generate
   
    ped_alg : entity work.ped_alg
	port map(
	  ap_clk        => clk,
	  ap_rst        => reset,
	  ap_start      => start,
	  ap_done       => done,
	  ap_idle       => idle,
	  
      -- How do I access these signals that aren't on s_axis or m_axis?
	  ped_val_i		=> "0000000111110100", -- Initial value set to 500, but should
	  -- take varying input after the SSR changes the median for all channels.
	  ped_val_o		=> PedSub_median,
	  accum_i		=> "00000000", -- Initial value set to zero but should change eventually
	  accum_o		=> PedSub_accum,

       -- Is the signal reading in: s_axis_data + '_r' or '_w'
	  tdata			=> s_axis_data_w.tdata,
	  tvalid		=> s_axis_data_w.tvalid,
	  tkeep0		=> s_axis_data_w.tkeep(0), -- Is this correct?
	  tkeep1		=> s_axis_data_w.tkeep(1),

       -- Is this _r?
	  tready		=> m_axis_data_r.tready,

	  treset		=> reset,
      -- _w or _r?	  
	  tlast			=> s_axis_data_w.tlast,
	  tvalid_out	=> m_axis_data_w.tvalid,
	  tkeep0_out	=> m_axis_data_w.tkeep(0),
	  tkeep1_out	=> m_axis_data_w.tkeep(1),
	  tready_out	=> s_axis_data_r.tready,
	  treset_out	=> open,
	  tlast_out     => m_axis_data_w.tlast,

	  -- 'Useless' validation ports for signal booleans:
	  ped_val_o_ap_vld      => open,
	  accum_o_ap_vld        => open,
	  ADC_ap_vld            => open,
	  tvalid_out_ap_vld         => open,
	  tkeep0_out_ap_vld         => open,
	  tkeep1_out_ap_vld         => open,
	  tready_out_ap_vld         => open,
	  treset_out_ap_vld         => open,
	  tlast_out_ap_vld          => open
	);
  
--    pedsub : entity work.PedestalSubtraction
--    port map( 
--      clk            => clk, 
--      reset          => pedsub_rst,   
--      s_axis_data_w  => s_axis_data_w,
--      s_axis_data_r  => s_axis_data_r,    
--      m_axis_data_w  => m_axis_data_w,
--      m_axis_data_r  => m_axis_data_r
--    );
    
--      pedSub_valid  <= '0';
--      pedSub_median <= (others => '0');
--      pedSub_accum  <= (others => '0');
  end generate;
end Behavioral;
